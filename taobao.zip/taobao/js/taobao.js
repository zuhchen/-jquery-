$(function() {
	<!--导航下拉菜单-->
	$(".td").hover(function() {
		$(this).css("color", "red");
		$(this).css("background", "white");
		$(this).find(".list").show();
		$(this).find(".list_left").show();
	}, function() {
		$(this).find(".list").hide();
		$(this).find(".list_left").hide();
		$(this).css("color", "#6c6c6c");
		$(".td").css("background", "#f5f5f5");
	});
	
	$(".list li").hover(function(){
		$(this).css("background","#ece4de")
	},function(){
		$(this).css("background","white")
	});
	
	$(".list_left li").hover(function(){
		$(this).css("background","#e8e0da")
	},function(){
		$(this).css("background","white")
	});

	<!--主题市场添加右箭头-->
	$(".body_border").find("td").append("<p>&gt;</p>");

	<!--去除input获得焦点时显示的边框-->
	$("input").focus(function() {
		$(this).css("outline", "none")
	});

	<!--键盘按下时去掉input提示字符-->
	$("input").onkeypress(function() {
		$(this).attr("placeholder", "")
	});
	
});
