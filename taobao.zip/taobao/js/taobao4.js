$(function(){
	$(".qrCodeClose").click(function(){
		$(".searchRight").css("display","none")
	});
});