$(function() {
	$("<img>").attr("src","images/smallPic.png").prependTo("#small td").css({
		"position":"relative",
		"top":"-15px",
		"left":"20px"
	});
	
	$("#small img").css("visibility","hidden");
	
	
	$("#small td").hover(function(){
		$(this).find("img").css("visibility","visible");
	},function(){
		$(this).find("img").css("visibility","hidden");
	});
});


