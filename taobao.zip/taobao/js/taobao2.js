$(function() {
	//图片数组
	var arrImg = ["images/1.jpg", "images/2.jpg", "images/3.jpg", "images/4.jpg", "images/5.jpg"];
	//加载图片和圆点
	for (var i = 0; i < arrImg.length; i++) {
		//添加li标签
		$("<li/>").css("background", "url(" + arrImg[i] + ")").appendTo(".scrollPictureWidth");
		$("<li/>").css("background", "url(" + arrImg[i] + ")").appendTo(".scrollPictureWidth2");

		//圆形索引,条状索引
		$("<li/>").appendTo(".index");
		$("<li/>").appendTo(".progressBar");
	}

	//获取宽度
	var picWidth = $(".scrollPictureWidth li").width();
	var index = 0;
	var index2 = 0;

	/* 移动图片 */
	function move(index) {
		$(".scrollPictureWidth").css("left", -picWidth * index);
		$(".index li").css("background", "#ffffff");
		$(".index li").eq(index).css("background", "#ff0000");
	}

	function move2(index2) {
		$(".scrollPictureWidth2").css("left", -picWidth * index2);
		$(".progressBar li").css("background", "#ff0000");
		$(".progressBar li").eq(index2).css("background", "#000000");
		$("#index").text(index2);
	}

	function changeImg() {
		move(index);
		if (index == 4) {
			index = -1;
		}
		index++;
	}

	function changeImg2() {
		move2(index2);
		if (index2 == 4) {
			index2 = -1;
		}
		(index2)++;
	}

	/* 图片自动轮播 */
	var time1 = setInterval(changeImg, 1500);
	var time2 = setInterval(changeImg2, 1500);

	/* 点击圆点切换图片 */
	$(".index li").click(function() {
		index = $(this).index();
		move(index);
	});

	$(".progressBar li").click(function() {
		index2 = $(this).index();
		move2(index2);
	});

	$(".scrollPics,.scrollPics2").mouseenter(function() {
		if ($(this).find("ul:first-child").is("ul")) {
			clearInterval(time1);
			time1 = null;
		}
		if ($(this).find("div:first-child").is("div")) {
			clearInterval(time2);
			time2 = null;
		}
		//显示左右控制按钮
		$(this).find(".pic_left, .pic_right").show().hover(function() {
				$(this).css("opacity", "1");
			},
			function() {
				$(this).css("opacity", "0.5");
			});
	});

	$(".scrollPics,.scrollPics2").mouseleave(function() {
		$(".pic_left,.pic_right").hide();
		if ($(this).find("ul:first-child").is("ul")) {
			if(time1!=null){
				clearInterval(time1);
				time1=null;
			}
			time1 = setInterval(changeImg, 1500);
		}
		if($(this).find("div:first-child").is("div")) {
			if(time2!=null){
				clearInterval(time2);
				time2=null;
			}
			time2 = setInterval(changeImg2, 1500);
		}
	});

	/* 点击按钮向左移动图片 */
	$(".pic_left").click(function() {
		if ($(this).parent().find("ul:first-child").is("ul")) {
			index = ((5 + --index) % 5);
			move(index);
		} 
		if ($(this).parent().find("div:first-child").is("div")){
			index2 = ((5 + --index2) % 5);
			move2(index2);
		}
	});

	// /*点击按钮向右移动图片  */
	$(".pic_right").click(function() {
		if ($(this).parent().find("ul:first-child").is("ul")) {
			index = ((++index) % 5);
			move(index);
		} 
		if ($(this).parent().find("div:first-child").is("div")){
			index2 = ((++index) % 5);
			move2(index2);
		}
	});
	
	

});
